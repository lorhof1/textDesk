for i in $(eval echo "{1..$(tput lines)}")
#"
do
  echo 
done
echo --Elite lxOS bash terminal--
#add back function or alias
echo "type back to go back"
bash