echo 1
bash main.sh