echo 2
bash main.sh