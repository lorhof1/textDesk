echo 0
bash main.sh