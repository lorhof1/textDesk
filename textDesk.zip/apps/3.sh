echo 3
bash main.sh