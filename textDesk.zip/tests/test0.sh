echo $(ls apps) > apps.list
applist=$(<"apps.list")
> apps.list
for word in $applist
do
    echo $word >> apps.list
done