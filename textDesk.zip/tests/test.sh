#cd apps
#for entry in $(ls)
#do
#  IFS=. read -r left right <<< "$entry"
#  cd ..
#  echo "$left" > apps.list
#  cd apps
#done
#cd ..
#echo > apps.list
#echo $(ls apps) > apps.list